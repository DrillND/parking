﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text != "" && comboBox1.Text != ""&& dateTimePicker1.Text !="")
            if (checkBox1.Checked)
            {
                
            }
            {
                dataGridView1.Rows.Add(textBox1.Text,comboBox1.Text,comboBox2.Text+" " + textBox4.Text + " : " + textBox5.Text);
                DateTime dateTime = new DateTime();
                var timesampm = comboBox2.Text;
                var h = textBox4.Text;
                var m = textBox5.Text;
               dateTime = Convert.ToDateTime(h);
                
                if (comboBox2.Text == "오전")
                {
                    
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

      

       

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //int c = dataGridView1.ce
            //if (textBox6.Text = dataGridView1.Rows[rowindeCells[0].value)
            //dataGridView1.Rows.Remove();
            //dataGridView3.Rows.Add();

            foreach (var item in dataGridView1.Rows)
            {
                DataGridViewRow dataGridViewRow = item as DataGridViewRow;

                if (dataGridViewRow.Cells[0].Value.ToString() == textBox6.Text)
                {
                    dataGridView1.Rows.Remove(dataGridViewRow);
                    var ampm = DateTime.Now.ToString("tt");
                    var time = DateTime.Now.ToString("h");
                    var time2 = DateTime.Now.ToString(":m");
                    dataGridView3.Rows.Add(dataGridViewRow.Cells[0].Value, dataGridViewRow.Cells[1].Value, dataGridViewRow.Cells[2].Value, ampm + time+time2);
                }
            }
        }
    }
}
